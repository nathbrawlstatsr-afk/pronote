# PRONOTE-CLONE-PHISHING-WEBSITE

Un clone de Pronote créé pour faire du harmeçonage et sensibilisé les élèves à ce type d'attaque informatique très fréquentes.

---
 
![Logo Pronote](./public/images/Logo-pronote.png)

---

### ATTENTION

_Ce projet est fait dans le cadre d'une démonstration et d'une campagne de prévention encadrées par mon propre lycée. Il ne s'agit en aucun cas d'une quelconque incitation à reproduire ce type de projet dans des fins malveillantes, ou dans un milieu non-encadrée._
